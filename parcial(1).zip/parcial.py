class Persona:
    def _init_(self, nombre, apellido, edad):
        self.__nombre = nombre
        self.__apellido = apellido
        self.__edad = edad

    def get_nombre(self):
        return self.__nombre

    def set_nombre(self, nombre):
        self.__nombre = nombre

    def get_apellido(self):
        return self.__apellido

    def set_apellido(self, apellido):
        self.__apellido = apellido

    def get_edad(self):
        return self.__edad

    def set_edad(self, edad):
        self.__edad = edad


class Empleado(Persona):
    def _init_(self, nombre, apellido, edad, salario, experiencia):
        super()._init_(nombre, apellido, edad)
        self.__salario = salario
        self.__experiencia = experiencia
        self.__cargo = self.calcular_cargo()

    def get_salario(self):
        return self.__salario

    def set_salario(self, salario):
        self.__salario = salario

    def get_experiencia(self):
        return self.__experiencia

    def set_experiencia(self, experiencia):
        self.__experiencia = experiencia

    def get_cargo(self):
        return self.__cargo

    def calcular_cargo(self):
        if self.get_salario() >= 5000000 and self.get_experiencia() >= 5 and 25 <= self.get_edad() <= 45:
            return "Senior"
        elif 900000 <= self.get_salario() <= 1200000 and 1 <= self.get_experiencia() <= 2 and 18 <= self.get_edad() <= 22:
            return "Junior"
        else:
            return "No aplica"

    def imprimir_detalle(self):
        print(f"Nombre: {self.get_nombre()} {self.get_apellido()}")
        print(f"Edad: {self.get_edad()}")
        print(f"Salario: {self.get_salario()}")
        print(f"Experiencia: {self.get_experiencia()}")
        print(f"Cargo: {self.get_cargo()}")


nombre = input("Digite su nombre: ")
apellido = input("Digite su apellido: ")
edad = int(input("Digite su edad: "))
salario = int(input("Digite su salario: "))
experiencia = int(input("Digite su experiencia: "))

empleado = Empleado(nombre, apellido, edad, salario, experiencia)
empleado.imprimir_detalle()
```